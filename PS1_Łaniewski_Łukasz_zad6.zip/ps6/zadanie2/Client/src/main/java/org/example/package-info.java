@javax.xml.bind.annotation.XmlSchema(namespace = "http://example.org/")
package org.example;
