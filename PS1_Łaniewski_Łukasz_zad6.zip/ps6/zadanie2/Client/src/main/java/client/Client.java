package client;

import java.net.MalformedURLException;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.example.HelloWorld;

public class Client {
    
    public static void main(String[] args) throws MalformedURLException {
        
        HttpsURLConnection.setDefaultHostnameVerifier((hostname, sslSession) -> true);
        
        System.setProperty("javax.net.ssl.trustStore", "clien_cacerts.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "Test123");
        
        
        URL url = new URL("https://localhost:8443/Server_1_0_SNAPSHOT_war/hello?wsdl");
        QName qname = new QName("http://example.org/", "HelloWorldImplService");
        Service service = Service.create(url, qname);
        
        HelloWorld hello = service.getPort(HelloWorld.class);
        System.out.println(hello.getHelloWorldAsString("test"));

    }
}
