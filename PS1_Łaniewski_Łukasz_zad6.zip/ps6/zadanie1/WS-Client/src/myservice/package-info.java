@javax.xml.bind.annotation.XmlSchema(namespace = "http://myservice/")
package myservice;
