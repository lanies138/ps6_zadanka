import myservice.ImageServerImpl;
import myservice.ImageServerImplService;

import javax.swing.*;
import javax.xml.ws.soap.MTOMFeature;

public class WSClient {

    public static void main(String[] args) {
        ImageServerImplService service = new ImageServerImplService();

      //  ProxySelector proxySelector = new CustomProxySelector();
       // ProxySelector.setDefault(proxySelector);

        ImageServerImpl port = service.getImageServerImplPort(new MTOMFeature());
        byte[] image = port.downloadImage("picture.png");

        JFrame frame = new JFrame();
        frame.setSize(600, 600);
        JLabel label = new JLabel(new ImageIcon(image));
        frame.add(label);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        System.out.println("imageServer.downloadImage(): Download Successful!");
    }
}
