package myservice;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.BindingType;
import javax.xml.ws.soap.MTOM;
import javax.xml.ws.soap.SOAPBinding;

@WebService
@MTOM
@BindingType(value = SOAPBinding.SOAP11HTTP_MTOM_BINDING)
public class ImageServerImpl {
    
    @WebMethod
    public String echo(String text) {
        return "Hallo " + text;
    }
    
    public Image downloadImage(String name) {
        File image = new File("/home/lukasz_laniewski/IdeaProjects/ps6/zadanie1/images/" + name);
        try {
            return ImageIO.read(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
